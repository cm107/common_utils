# common_utils
Common python utilities that can be broadly used across repositories.

## Installation
```console
pip install https://github.com/cm107/common_utils/archive/v0.1.zip
```