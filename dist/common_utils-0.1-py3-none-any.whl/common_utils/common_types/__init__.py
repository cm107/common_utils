from .common import Keypoint, BoundingBox, Size, Point, Rectangle, Polygon, \
    Circle, Ellipse, Resize, Interval
from .bbox import BBox, ConstantAR_BBox