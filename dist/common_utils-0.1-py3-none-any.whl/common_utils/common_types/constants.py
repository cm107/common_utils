import numpy as np

number_types = [
    int, float,
    np.int8, np.int16, np.int32, np.int64,
    np.float16, np.float32, np.float64
]